# VIDARA AI STUDY — One-Click Cloud APK Builder (GitHub Actions)

This project wraps **VIDARA AI STUDY** (`app/src/main/assets/index.html`) into a native Android WebView application with:
- Custom **VIDARA** launcher icon & animated logo splash screen
- Native Android **Print / Save as PDF** dialog (`PrintManager`)
- Native Android **Downloads** saving for Word (`.doc`), CSV & JSON backups (`MediaStore.Downloads`)
- Universal **Files / Drive / Camera / Gallery** picker (`*/*` PDF, Word, Text, Image uploads)
- Step-by-step **Android Back button** support (closes open popups/modals first)

## How to Build Your APK on GitHub
1. Delete the old `.zip` in your GitHub repository and upload `vidara-ai-study-apk-builder.zip`.
2. Open the **Actions** tab and wait ~2–3 minutes for **Build Android APK** to finish.
3. Download **VIDARA-AI-STUDY-Debug-APK**, extract `app-debug.apk`, and install on your tablet/phone.
