# VIDARA AI STUDY — Android APK Builder (GitHub Actions)

This project wraps **VIDARA AI STUDY** (`app/src/main/assets/index.html`) in a native Android WebView app with:
- VIDARA launcher icon and animated logo splash screen
- Android **Print / Save as PDF** (clean A4 layout for papers, OMR sheets and handwritten notes)
- Android **Downloads** saving for Word (`.doc`), slides (`.ppt`), SVG, CSV and JSON files
- **Files / Drive / Camera / Gallery** picker for PDF, Word, text and image study material
- Live camera viewfinder (asks for camera permission only when it is first used)
- Offline ML Kit OCR (Latin and Devanagari) that works without internet
- Step-by-step **Android Back button** support (closes open dialogs first)

## How to build the APK on GitHub

GitHub Actions builds from the **root** of a repository, so the zip file itself cannot be uploaded as-is.

1. Unzip `vidyasetu-apk-builder_*.zip` on your computer. You get a folder named `vidyasetu-apk-builder`.
2. Open that folder and select everything inside it (`.github`, `app`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `README.md`). Do **not** select the folder itself.
3. In your GitHub repository, upload those items to the root (or replace the old files). The `.github/workflows/build-apk.yml` file must sit at `.github/workflows/` in the repository root.
4. Open the **Actions** tab and wait about 2–3 minutes for **Build Android APK** to finish.
5. Download the **VIDARA-AI-STUDY-Debug-APK** artifact, extract `app-debug.apk`, and install it on your phone or tablet. You may need to allow installation from unknown sources.

## Notes
- The debug APK is signed with the default debug key. For Play Store distribution you need a release key.
- Online Gemini AI is optional. Without an API key (or without internet) the app uses its offline engine and on-device OCR.
