/* ==================== VIDARA FEATURES LAYER ====================
   Loaded after app.js. Everything here adds to the app: it wraps existing
   functions where needed and never rewrites the core flows. */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const esc = v => (typeof escapeHtml === 'function' ? escapeHtml(String(v == null ? '' : v)) : String(v == null ? '' : v));
  const LS = {
    get(key, fallback) {
      try { const raw = localStorage.getItem(key); return raw == null ? fallback : JSON.parse(raw); } catch (e) { return fallback; }
    },
    set(key, value) {
      try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch (e) { return false; }
    }
  };
  const safe = (label, fn) => { try { return fn(); } catch (e) { console.warn('[VIDARA] ' + label + ' failed:', e); return undefined; } };

  /* ---------- 1. QUESTION BANK IMPORT (CSV) ---------- */
  const CUSTOM_KEY = 'vidara_custom_questions';
  const TYPE_ALIASES = {
    'mcq': 'MCQ', 'one-mark': 'One-Mark', 'one mark': 'One-Mark', '1 mark': 'One-Mark', 'one-word': 'One-Mark',
    'short answer': 'Short Answer', 'sa': 'Short Answer', 'long answer': 'Long Answer', 'la': 'Long Answer',
    'numerical': 'Numerical / A&R', 'numerical / a&r': 'Numerical / A&R', 'numerical/a&r': 'Numerical / A&R'
  };
  const DIFFS = { easy: 'Easy', moderate: 'Moderate', hard: 'Hard' };
  const CSV_HEADERS = ['class', 'subject', 'chapter', 'topic', 'type', 'marks', 'difficulty', 'question', 'option_a', 'option_b', 'option_c', 'option_d', 'correct', 'answer'];
  const CSV_EXAMPLE = [
    ['Class 10', 'Social Science', '1', 'Rise of Nationalism', 'MCQ', '1', 'Easy', 'Which country was unified in 1871?', 'France', 'Germany', 'Italy', 'Spain', 'B', ''],
    ['Class 10', 'Social Science', '1', 'Rise of Nationalism', 'Short Answer', '3', 'Moderate', 'Why did the French Revolution spread nationalism?', '', '', '', '', '', 'It spread ideas of liberty, equality and nation-state.']
  ];

  function parseCsv(text) {
    const src = String(text || '').replace(/^﻿/, '');
    const rows = [];
    let row = [], field = '', inQuotes = false;
    for (let i = 0; i < src.length; i++) {
      const c = src[i];
      if (inQuotes) {
        if (c === '"') {
          if (src[i + 1] === '"') { field += '"'; i++; } else { inQuotes = false; }
        } else {
          field += c;
        }
      } else if (c === '"') {
        inQuotes = true;
      } else if (c === ',') {
        row.push(field); field = '';
      } else if (c === '\n' || c === '\r') {
        if (c === '\r' && src[i + 1] === '\n') i++;
        row.push(field); rows.push(row); row = []; field = '';
      } else {
        field += c;
      }
    }
    if (field.length || row.length) { row.push(field); rows.push(row); }
    return rows.filter(r => r.some(cell => String(cell).trim() !== ''));
  }

  function validateCsvRows(rows) {
    const questions = [], errors = [];
    if (!rows.length) return { questions, errors: ['The file is empty.'] };
    const header = rows[0].map(h => String(h).trim().toLowerCase().replace(/\s+/g, '_'));
    const missing = ['class', 'subject', 'chapter', 'type', 'marks', 'question'].filter(k => !header.includes(k));
    if (missing.length) return { questions, errors: ['Missing column(s): ' + missing.join(', ') + '. Download the template to see the right layout.'] };
    const cell = (r, name) => { const i = header.indexOf(name); return i >= 0 ? String(r[i] == null ? '' : r[i]).trim() : ''; };
    const stamp = Date.now().toString(36);

    rows.slice(1).forEach((r, idx) => {
      const line = idx + 2;
      const cls = cell(r, 'class'), subj = cell(r, 'subject');
      const chRaw = cell(r, 'chapter'), chNum = parseInt(chRaw, 10);
      const type = TYPE_ALIASES[cell(r, 'type').toLowerCase()];
      const marks = parseInt(cell(r, 'marks'), 10);
      const stem = cell(r, 'question');
      const diff = DIFFS[cell(r, 'difficulty').toLowerCase()] || 'Moderate';
      const bad = [];
      let chObj = null;
      if (!CURRICULUM[cls]) bad.push('unknown class "' + cls + '"');
      else if (!CURRICULUM[cls][subj]) bad.push('subject "' + subj + '" is not in ' + cls);
      else {
        chObj = CURRICULUM[cls][subj].find(c => c.num === chNum);
        if (!chObj) bad.push('chapter "' + chRaw + '" is not in ' + subj);
      }
      if (!type) bad.push('unknown type "' + cell(r, 'type') + '"');
      if (!(marks > 0)) bad.push('marks must be a positive number');
      if (!stem) bad.push('question text is empty');

      let options = [], correctIndex = -1, answerKey = '';
      if (type === 'MCQ') {
        options = ['option_a', 'option_b', 'option_c', 'option_d'].map(k => cell(r, k));
        const letter = cell(r, 'correct').toUpperCase();
        const li = letter.length === 1 ? 'ABCD'.indexOf(letter) : -1;
        if (options.some(o => !o)) bad.push('MCQ needs option_a, option_b, option_c and option_d');
        else if (new Set(options.map(o => o.toLowerCase())).size !== 4) bad.push('MCQ options must be different');
        if (li < 0) bad.push('correct must be A, B, C or D');
        else { correctIndex = li; answerKey = letter + ' (' + options[li] + ')'; }
      } else {
        answerKey = cell(r, 'answer') || 'Answer not provided';
      }
      if (bad.length) { errors.push('Row ' + line + ': ' + bad.join('; ')); return; }

      questions.push({
        id: 'csv_' + stamp + '_' + idx + '_' + Math.random().toString(36).slice(2, 7),
        cls, subj, ch: chNum, topic: cell(r, 'topic') || chObj.name,
        type, marks, diff, stem, options, correctIndex, answerKey,
        brief: answerKey, detailed: answerKey, isPyq: false, source: 'Imported (CSV)', userAuthored: true
      });
    });
    return { questions, errors };
  }

  function loadCustomQuestions() {
    LS.get(CUSTOM_KEY, []).forEach(q => {
      if (!state.bank.some(x => x.id === q.id)) state.bank.push(q);
    });
  }

  function csvCell(v) {
    const s = String(v == null ? '' : v);
    return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }
  function csvLine(arr) { return arr.map(csvCell).join(','); }

  function downloadTemplate() {
    const text = '﻿' + [csvLine(CSV_HEADERS)].concat(CSV_EXAMPLE.map(csvLine)).join('\r\n') + '\r\n';
    triggerSafeFileSave('VIDARA_Question_Import_Template.csv', 'text/csv', text);
  }

  function reportImport(message, errors) {
    const box = $('csv-import-result');
    if (!box) return;
    box.innerHTML = '<p class="font-bold ' + (errors.length ? 'text-amber-700' : 'text-emerald-700') + '">' + esc(message) + '</p>' +
      (errors.length ? '<ul class="list-disc pl-5 text-[11px] text-rose-700 max-h-40 overflow-auto">' + errors.slice(0, 50).map(e => '<li>' + esc(e) + '</li>').join('') + (errors.length > 50 ? '<li>…and ' + (errors.length - 50) + ' more</li>' : '') + '</ul>' : '');
  }

  function importCsvText(text) {
    const { questions, errors } = validateCsvRows(parseCsv(text));
    if (!questions.length) {
      reportImport('No questions were imported. Fix the rows below and try again.', errors);
      return;
    }
    const saved = LS.get(CUSTOM_KEY, []);
    const merged = saved.concat(questions);
    if (!LS.set(CUSTOM_KEY, merged)) {
      reportImport('Could not save the questions: browser storage is full or blocked.', errors);
      return;
    }
    questions.forEach(q => state.bank.push(q));
    if (typeof updateStep4Availability === 'function') safe('availability', () => updateStep4Availability());
    reportImport(questions.length + ' question(s) imported' + (errors.length ? ', ' + errors.length + ' row(s) skipped' : '') + '.', errors);
    showToast(questions.length + ' questions imported to the bank.');
  }

  function removeImportedQuestions() {
    const count = LS.get(CUSTOM_KEY, []).length;
    if (!count) { showToast('No imported questions to remove.'); return; }
    LS.set(CUSTOM_KEY, []);
    state.bank = state.bank.filter(q => !q.userAuthored);
    reportImport(count + ' imported question(s) removed.', []);
    showToast('Imported questions removed.');
  }

  function buildImportCard() {
    const anchor = $('btn-download-backup');
    if (!anchor || $('csv-import-card')) return;
    const card = document.createElement('div');
    card.id = 'csv-import-card';
    card.className = 'space-y-2 rounded-xl border border-emerald-200 dark:border-emerald-800 p-3 bg-emerald-50/40 dark:bg-emerald-950/20';
    card.innerHTML =
      '<div class="text-xs font-extrabold text-emerald-900 dark:text-emerald-200 uppercase">Question bank import (CSV)</div>' +
      '<p class="text-[11px] text-slate-600 dark:text-slate-400">Add your own questions in bulk. Use the template: one row per question, with class, subject and chapter names exactly as in the app.</p>' +
      '<div class="flex flex-wrap gap-2">' +
      '<button id="csv-template-btn" type="button" class="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-emerald-300 text-xs font-bold">Download CSV template</button>' +
      '<label class="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold cursor-pointer">Choose CSV file<input id="csv-file-input" type="file" accept=".csv,text/csv" class="hidden" /></label>' +
      '<button id="csv-remove-btn" type="button" class="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-rose-300 text-rose-700 text-xs font-bold">Remove imported questions</button>' +
      '</div><div id="csv-import-result" class="text-xs space-y-1"></div>';
    anchor.parentElement.insertAdjacentElement('afterend', card);

    $('csv-template-btn').addEventListener('click', downloadTemplate);
    $('csv-remove-btn').addEventListener('click', removeImportedQuestions);
    $('csv-file-input').addEventListener('change', e => {
      const file = e.target.files && e.target.files[0];
      e.target.value = '';
      if (!file) return;
      if (file.size > 2 * 1024 * 1024) { reportImport('The file is larger than 2 MB. Split it into smaller files.', []); return; }
      const reader = new FileReader();
      reader.onload = () => safe('import', () => importCsvText(String(reader.result || '')));
      reader.onerror = () => reportImport('Could not read the file.', []);
      reader.readAsText(file);
    });
  }

  /* ---------- 2. PAPER CHECK ---------- */
  function paperIssues(qs) {
    const errors = [], warnings = [];
    if (!qs.length) return { errors: ['No questions selected yet.'], warnings, totalMarks: 0 };
    const seen = new Map();
    qs.forEach((q, i) => {
      const n = i + 1;
      const stem = String(q.stem || '').trim();
      if (!stem) errors.push('Q' + n + ': question text is empty');
      if (!(parseInt(q.marks, 10) > 0)) errors.push('Q' + n + ': marks are not set');
      if (q.type === 'MCQ') {
        const opts = Array.isArray(q.options) ? q.options : [];
        if (opts.length !== 4 || opts.some(o => !String(o).trim())) errors.push('Q' + n + ': MCQ needs 4 non-empty options');
        else if (new Set(opts.map(o => String(o).trim().toLowerCase())).size !== 4) errors.push('Q' + n + ': MCQ has duplicate options');
        if (!(q.correctIndex >= 0 && q.correctIndex < opts.length)) errors.push('Q' + n + ': no valid correct option');
      } else if (!q.answerKey || /not provided|Key principle and explanation/i.test(q.answerKey)) {
        warnings.push('Q' + n + ': answer key is missing or generic');
      }
      const key = stem.toLowerCase().replace(/\s+/g, ' ');
      if (key) {
        if (seen.has(key)) errors.push('Q' + n + ': same question as Q' + seen.get(key));
        else seen.set(key, n);
      }
    });
    const totalMarks = qs.reduce((a, q) => a + (parseInt(q.marks, 10) || 0), 0);
    return { errors, warnings, totalMarks };
  }

  function runPaperCheck() {
    const out = $('paper-check-output');
    if (!out) return;
    const qs = getSelectedQuestions();
    const r = paperIssues(qs);
    if (!qs.length) { out.innerHTML = '<p class="text-xs text-slate-500">Select or auto-pick questions first.</p>'; return; }
    const ok = r.errors.length === 0;
    out.innerHTML = '<div class="rounded-xl border p-3 text-xs space-y-1 ' + (ok ? 'border-emerald-300 bg-emerald-50 text-emerald-900' : 'border-rose-300 bg-rose-50 text-rose-900') + '">' +
      '<div class="font-extrabold">' + (ok ? '✓ Paper check passed' : '✕ ' + r.errors.length + ' problem(s) to fix before printing') + '</div>' +
      '<div>' + qs.length + ' questions • ' + r.totalMarks + ' marks</div>' +
      (r.errors.length ? '<ul class="list-disc pl-5">' + r.errors.slice(0, 30).map(e => '<li>' + esc(e) + '</li>').join('') + '</ul>' : '') +
      (r.warnings.length ? '<details><summary class="cursor-pointer font-bold">' + r.warnings.length + ' warning(s)</summary><ul class="list-disc pl-5 mt-1">' + r.warnings.slice(0, 30).map(w => '<li>' + esc(w) + '</li>').join('') + '</ul></details>' : '') +
      '</div>';
  }

  /* ---------- 3. PAPER HEADER + SET A/B ---------- */
  const META_KEY = 'vidara_paper_meta';
  function paperMetaValues() {
    const d = $('pm-date'), t = $('pm-teacher'), s = $('pm-set');
    return { date: d ? d.value : '', teacher: t ? t.value.trim() : '', set: s ? s.value : '' };
  }
  function paperSetValue() { return paperMetaValues().set; }
  function paperSetSuffix() { const s = paperSetValue(); return s ? ' — Set ' + s : ''; }
  function paperDateText() {
    const d = paperMetaValues().date;
    if (!d) return '__________';
    const [y, m, day] = d.split('-');
    return day && m && y ? day + '-' + m + '-' + y : d;
  }
  function paperTeacherText() { return paperMetaValues().teacher || '____________'; }

  function hashSeed(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function seededRandom(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function shuffled(arr, rand) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      const t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  // Set A: same question order, options reordered. Set B: questions and options reordered.
  // Answer keys are remapped, so each set's key matches its own printed paper.
  function applyPaperSet(qs) {
    const set = paperSetValue();
    if (!set) return qs;
    const rand = seededRandom(hashSeed('VIDARA-SET-' + set));
    const order = set === 'B' ? shuffled(qs.map((_, i) => i), rand) : qs.map((_, i) => i);
    return order.map(i => {
      const q = qs[i];
      if (q.type !== 'MCQ' || !Array.isArray(q.options) || q.options.length !== 4 || !(q.correctIndex >= 0)) return Object.assign({}, q);
      const perm = shuffled([0, 1, 2, 3], rand); // perm[newPosition] = original option index
      const options = perm.map(o => q.options[o]);
      const correctIndex = perm.indexOf(q.correctIndex);
      return Object.assign({}, q, { options, correctIndex, answerKey: 'ABCD'[correctIndex] + ' (' + options[correctIndex] + ')' });
    });
  }

  function buildPaperControls() {
    const preview = $('export-preview-content');
    if (!preview || $('paper-meta-bar')) return;
    const saved = LS.get(META_KEY, {});
    const bar = document.createElement('div');
    bar.id = 'paper-meta-bar';
    bar.className = 'flex flex-wrap gap-2 items-end text-xs no-print';
    bar.innerHTML =
      '<label class="flex flex-col gap-0.5 font-bold text-slate-600 dark:text-slate-300">Exam date<input id="pm-date" type="date" class="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2 py-1" /></label>' +
      '<label class="flex flex-col gap-0.5 font-bold text-slate-600 dark:text-slate-300">Teacher<input id="pm-teacher" type="text" maxlength="60" placeholder="Teacher name" class="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2 py-1 w-40" /></label>' +
      '<label class="flex flex-col gap-0.5 font-bold text-slate-600 dark:text-slate-300">Paper set<select id="pm-set" class="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2 py-1"><option value="">Single set</option><option value="A">Set A</option><option value="B">Set B</option></select></label>';
    const check = document.createElement('div');
    check.id = 'paper-check-output';
    check.className = 'no-print';
    preview.parentElement.insertBefore(bar, preview);
    preview.parentElement.insertBefore(check, preview);

    $('pm-date').value = saved.date || '';
    $('pm-teacher').value = saved.teacher || '';
    $('pm-set').value = saved.set || '';
    const refresh = () => {
      LS.set(META_KEY, paperMetaValues());
      if (getSelectedQuestions().length && typeof renderExportPreview === 'function') safe('preview', () => renderExportPreview());
      runPaperCheck();
    };
    ['pm-date', 'pm-teacher', 'pm-set'].forEach(id => $(id).addEventListener('change', refresh));
    $('pm-teacher').addEventListener('input', () => LS.set(META_KEY, paperMetaValues()));

    const printBtn = $('btn-print-pdf');
    if (printBtn && !$('btn-paper-check')) {
      const b = document.createElement('button');
      b.id = 'btn-paper-check';
      b.type = 'button';
      b.className = 'px-3.5 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold no-print';
      b.textContent = '✓ Check paper';
      b.addEventListener('click', runPaperCheck);
      printBtn.insertAdjacentElement('beforebegin', b);
    }
  }

  /* ---------- 4. WEAK-TOPIC ANALYTICS (student) ---------- */
  function weakTopics(attempts) {
    const agg = {};
    attempts.forEach(att => (att.topics || []).forEach(t => {
      const k = t.name || 'General';
      if (!agg[k]) agg[k] = { name: k, c: 0, tot: 0 };
      agg[k].c += t.c || 0;
      agg[k].tot += t.tot || 0;
    }));
    return Object.values(agg).filter(t => t.tot > 0)
      .map(t => Object.assign({}, t, { acc: Math.round((100 * t.c) / t.tot) }))
      .sort((a, b) => (a.acc - b.acc) || (b.tot - a.tot));
  }

  function renderWeakTopics() {
    let host = $('weak-topics-panel');
    if (!host) {
      const canvas = $('analytics-chart');
      if (!canvas || !canvas.parentElement) return;
      host = document.createElement('div');
      host.id = 'weak-topics-panel';
      host.className = 'rounded-2xl border border-amber-300 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/20 p-4 space-y-2 mt-4';
      canvas.parentElement.insertAdjacentElement('afterend', host);
    }
    const attempts = typeof getStudentAttempts === 'function' ? getStudentAttempts() : [];
    if (!attempts.length) {
      host.innerHTML = '<div class="text-sm font-extrabold">Weak topics</div><p class="text-xs text-slate-600 dark:text-slate-400">Finish a practice test to see which topics need revision.</p>';
      return;
    }
    const list = weakTopics(attempts);
    if (!list.length) {
      host.innerHTML = '<div class="text-sm font-extrabold">Weak topics</div><p class="text-xs text-slate-600 dark:text-slate-400">No topic data yet.</p>';
      return;
    }
    const rows = list.slice(0, 6).map(t => {
      const tone = t.acc < 60 ? 'bg-rose-500' : t.acc < 80 ? 'bg-amber-500' : 'bg-emerald-500';
      const tag = t.acc < 60 ? '<span class="text-rose-700 font-bold">Revise first</span>' : '';
      return '<div class="space-y-0.5"><div class="flex justify-between text-xs font-semibold"><span>' + esc(t.name) + '</span><span>' + t.acc + '% (' + t.c + '/' + t.tot + ') ' + tag + '</span></div>' +
        '<div class="h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden"><div class="h-2 ' + tone + '" style="width:' + t.acc + '%"></div></div></div>';
    }).join('');
    host.innerHTML = '<div class="text-sm font-extrabold">Weak topics (lowest accuracy first)</div>' + rows;
  }

  // Wrap the existing analytics renderer so the panel refreshes with it.
  function wrapAnalytics() {
    if (typeof renderStudentAnalytics !== 'function' || renderStudentAnalytics.__vidaraWrapped) return;
    const original = renderStudentAnalytics;
    const wrapped = function () {
      const result = original.apply(this, arguments);
      safe('weak topics', renderWeakTopics);
      return result;
    };
    wrapped.__vidaraWrapped = true;
    renderStudentAnalytics = wrapped;
  }

  /* ---------- 5. OMR CLASS SCORE SHEET ---------- */
  const OMR_CLASS_KEY = 'vidara_omr_class_sheet';
  let clearArmed = false;

  function saveOmrToClassSheet() {
    const r = state.omrLastResult;
    if (!r) { showToast('Auto-check a student OMR sheet first.'); return; }
    const sheet = LS.get(OMR_CLASS_KEY, []);
    const subjStats = {};
    Object.keys(r.subjStats || {}).forEach(k => { subjStats[k] = { score: r.subjStats[k].score, max: r.subjStats[k].max }; });
    const entry = {
      studentName: r.studentName, totalScore: r.totalScore, maxScore: r.maxScore,
      correct: r.correct, wrong: r.wrong, unattempted: r.unattempted, acc: r.acc,
      subjStats, savedAt: new Date().toLocaleString('en-IN')
    };
    const idx = sheet.findIndex(s => String(s.studentName).toLowerCase() === String(r.studentName).toLowerCase());
    if (idx >= 0) sheet[idx] = entry; else sheet.push(entry);
    if (!LS.set(OMR_CLASS_KEY, sheet)) { showToast('Could not save: browser storage is full or blocked.'); return; }
    updateClassSheetCount();
    showToast(r.studentName + ' saved to class sheet (' + sheet.length + ' students).');
  }

  function classRanks(sorted) {
    return sorted.map(s => 1 + sorted.filter(o => o.totalScore > s.totalScore).length);
  }

  function downloadOmrClassSheet() {
    const sheet = LS.get(OMR_CLASS_KEY, []);
    if (!sheet.length) { showToast('No students saved yet. Auto-check a sheet, then press Save to class sheet.'); return; }
    const subjects = [];
    sheet.forEach(s => Object.keys(s.subjStats || {}).forEach(k => { if (!subjects.includes(k)) subjects.push(k); }));
    const sorted = sheet.slice().sort((a, b) => (b.totalScore - a.totalScore) || (b.acc - a.acc));
    const ranks = classRanks(sorted);
    const lines = [csvLine(['Rank', 'Student', 'Total', 'Max', 'Percent', 'Correct', 'Wrong', 'Unattempted', 'Accuracy %'].concat(subjects.map(s => s + ' score')))];
    sorted.forEach((s, i) => {
      const pct = s.maxScore ? Math.round((100 * s.totalScore) / s.maxScore) : 0;
      lines.push(csvLine([ranks[i], s.studentName, s.totalScore, s.maxScore, pct, s.correct, s.wrong, s.unattempted, s.acc]
        .concat(subjects.map(sb => (s.subjStats && s.subjStats[sb]) ? s.subjStats[sb].score : ''))));
    });
    triggerSafeFileSave('VIDARA_OMR_Class_Sheet_' + Date.now() + '.csv', 'text/csv', '﻿' + lines.join('\r\n') + '\r\n');
  }

  function clearOmrClassSheet(btn) {
    if (!clearArmed) {
      clearArmed = true;
      btn.textContent = 'Tap again to clear all';
      setTimeout(() => { clearArmed = false; btn.textContent = '🗑 Clear class sheet'; }, 4000);
      return;
    }
    clearArmed = false;
    LS.set(OMR_CLASS_KEY, []);
    btn.textContent = '🗑 Clear class sheet';
    updateClassSheetCount();
    showToast('Class sheet cleared.');
  }

  function updateClassSheetCount() {
    const el = $('omr-class-count');
    if (el) el.textContent = 'Class sheet: ' + LS.get(OMR_CLASS_KEY, []).length + ' student(s)';
  }

  function buildOmrControls() {
    const dl = $('btn-omr-download-csv');
    if (!dl || $('omr-class-controls')) return;
    const wrap = document.createElement('div');
    wrap.id = 'omr-class-controls';
    wrap.className = 'flex flex-wrap items-center gap-2 text-xs no-print';
    wrap.innerHTML =
      '<button id="btn-omr-save-class" type="button" class="px-3 py-1.5 rounded-lg bg-teal-600 text-white font-bold">➕ Save to class sheet</button>' +
      '<button id="btn-omr-class-csv" type="button" class="px-3 py-1.5 rounded-lg bg-emerald-700 text-white font-bold">⬇ Class sheet (CSV)</button>' +
      '<button id="btn-omr-class-clear" type="button" class="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-rose-300 text-rose-700 font-bold">🗑 Clear class sheet</button>' +
      '<span id="omr-class-count" class="font-semibold text-slate-600 dark:text-slate-300"></span>';
    dl.insertAdjacentElement('afterend', wrap);
    $('btn-omr-save-class').addEventListener('click', saveOmrToClassSheet);
    $('btn-omr-class-csv').addEventListener('click', downloadOmrClassSheet);
    $('btn-omr-class-clear').addEventListener('click', e => clearOmrClassSheet(e.currentTarget));
    updateClassSheetCount();
  }

  /* ---------- 6. OFFLINE WEB (service worker, web only) ---------- */
  function registerOfflineCache() {
    if (!('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol)) return;
    navigator.serviceWorker.register('sw.js').catch(err => console.warn('[VIDARA] offline cache not registered:', err));
  }

  /* ---------- INIT ---------- */
  function initFeatures() {
    safe('load custom questions', loadCustomQuestions);
    safe('import card', buildImportCard);
    safe('paper controls', buildPaperControls);
    safe('omr controls', buildOmrControls);
    safe('analytics wrap', wrapAnalytics);
    safe('offline cache', registerOfflineCache);
  }

  window.VIDARA_FEATURES = { parseCsv, validateCsvRows, paperIssues, applyPaperSet, weakTopics, initFeatures };
  // Helpers used by app.js at render time must be global.
  window.paperSetSuffix = paperSetSuffix;
  window.paperDateText = paperDateText;
  window.paperTeacherText = paperTeacherText;
  window.applyPaperSet = applyPaperSet;
  initFeatures();
})();
