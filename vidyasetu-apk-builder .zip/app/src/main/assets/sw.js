/* VIDARA offline cache (web only). Caches the app shell and every successful GET.
   Requests are never cached when they are POST (for example, the optional Gemini calls). */
const CACHE = 'vidara-shell-v2';
const SHELL = ['./', './index.html', './app.js', './features.js', './manifest.json', './icon.png'];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  event.respondWith(
    caches.open(CACHE).then(async cache => {
      const cached = await cache.match(req, { ignoreSearch: true });
      const network = fetch(req)
        .then(res => {
          if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone()).catch(() => {});
          return res;
        })
        .catch(() => null);
      if (cached) return cached;
      const res = await network;
      return res || new Response('You are offline and this page is not cached yet.', { status: 503, statusText: 'Offline' });
    })
  );
});
