package com.vidara.aistudy

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingCameraUri: Uri? = null

    /** A download waiting for legacy (Android 9 and older) storage permission. */
    private class PendingSave(val name: String, val bytes: ByteArray)
    private var pendingSave: PendingSave? = null

    private val legacyStoragePermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val save = pendingSave
        pendingSave = null
        if (granted && save != null) {
            writeLegacyDownload(save.name, save.bytes)
        } else {
            Toast.makeText(this, "Storage permission is needed to save files to Downloads.", Toast.LENGTH_LONG).show()
        }
    }

    /** A page's camera request waiting for the Android camera permission (asked only when the live viewfinder needs it). */
    private var pendingCameraRequest: PermissionRequest? = null
    private val webCameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val req = pendingCameraRequest
        pendingCameraRequest = null
        if (req == null) return@registerForActivityResult
        if (granted) req.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) else req.deny()
    }

    // Photo capture and the system file picker run in their own apps, so they need no app permission.
    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val camUri = pendingCameraUri
        val uris: Array<Uri>? = if (result.resultCode == Activity.RESULT_OK) {
            val dataUri = result.data?.data
            when {
                dataUri != null -> {
                    deleteEmptyCameraRow(camUri)
                    arrayOf(dataUri)
                }
                camUri != null -> arrayOf(camUri)
                else -> null
            }
        } else null
        if (uris == null) deleteEmptyCameraRow(camUri)
        filePathCallback?.onReceiveValue(uris)
        filePathCallback = null
        pendingCameraUri = null
    }

    /** Removes the MediaStore placeholder created for a camera shot the user cancelled or did not use. */
    private fun deleteEmptyCameraRow(uri: Uri?) {
        if (uri == null) return
        try {
            contentResolver.delete(uri, null, null)
        } catch (_: Exception) {
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        return true
                    } catch (_: Exception) {
                    }
                }
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(
                    "window.print = function() { if (window.AndroidBridge) AndroidBridge.printPage('VIDARA_AI_STUDY_Paper'); };",
                    null
                )
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            // Only the live viewfinder's camera request is granted. Audio is never used by this app, so it is refused.
            override fun onPermissionRequest(request: PermissionRequest?) {
                runOnUiThread {
                    val req = request ?: return@runOnUiThread
                    if (!req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                        req.deny()
                        return@runOnUiThread
                    }
                    val cameraGranted = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED
                    if (cameraGranted) {
                        req.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                    } else {
                        pendingCameraRequest?.deny()
                        pendingCameraRequest = req
                        webCameraPermission.launch(Manifest.permission.CAMERA)
                    }
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback

                val rawAccept = fileChooserParams?.acceptTypes?.firstOrNull()?.trim() ?: "*/*"
                val isImageOnly = rawAccept.startsWith("image/") || fileChooserParams?.isCaptureEnabled == true
                // Never pass file extensions such as ".pdf" as an Intent MIME type on Android.
                val safeMime = if (isImageOnly) "image/*" else "*/*"

                val contentIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = safeMime
                }
                val chooser = Intent(Intent.ACTION_CHOOSER).apply {
                    putExtra(Intent.EXTRA_INTENT, contentIntent)
                    putExtra(
                        Intent.EXTRA_TITLE,
                        if (isImageOnly) "Choose Camera or Gallery" else "Choose Study Material (PDF, Word, Text, Image)"
                    )
                }

                if (isImageOnly) {
                    try {
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "VIDARA_Scan_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        }
                        pendingCameraUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        val camUri = pendingCameraUri
                        if (camUri != null) {
                            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                                putExtra(MediaStore.EXTRA_OUTPUT, camUri)
                                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            if (fileChooserParams?.isCaptureEnabled == true) {
                                // Camera button: open the camera directly.
                                fileChooserLauncher.launch(cameraIntent)
                                return true
                            }
                            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(cameraIntent))
                        }
                    } catch (_: Exception) {
                    }
                }

                return try {
                    fileChooserLauncher.launch(chooser)
                    true
                } catch (e: Exception) {
                    deleteEmptyCameraRow(pendingCameraUri)
                    pendingCameraUri = null
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = null
                    Toast.makeText(this@MainActivity, "Could not open file chooser: ${e.message}", Toast.LENGTH_LONG).show()
                    false
                }
            }
        }

        webView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "(function(){ return window.handleAndroidBack ? window.handleAndroidBack() : 'EXIT'; })()"
                ) { result ->
                    if (result != null && result.contains("EXIT")) {
                        finish()
                    }
                }
            }
        })
    }

    /** Writes to Downloads on Android 9 and older, where the public Downloads folder is a plain file path. */
    private fun writeLegacyDownload(name: String, bytes: ByteArray) {
        try {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            File(dir, name).writeBytes(bytes)
            Toast.makeText(this, "Saved to Downloads: $name", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun printHtml(jobName: String?, htmlContent: String?) {
            val safeJob = if (jobName.isNullOrBlank()) "VIDARA_AI_STUDY_Document" else jobName
            val body = htmlContent ?: return
            runOnUiThread {
                try {
                    // The print adapter keeps this WebView alive while printing; the framework releases it afterwards.
                    val printWebView = WebView(this@MainActivity)
                    printWebView.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            try {
                                val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                                val adapter = printWebView.createPrintDocumentAdapter(safeJob)
                                val attrs = PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build()
                                printManager.print(safeJob, adapter, attrs)
                            } catch (e: Exception) {
                                Toast.makeText(this@MainActivity, "Print failed: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    printWebView.loadDataWithBaseURL(null, body, "text/html", "UTF-8", null)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Print init failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun runOfflineOcr(base64DataUrl: String?, lang: String?, callbackId: String?) {
            val cb = callbackId ?: return
            val raw = base64DataUrl ?: ""
            val cleanB64 = raw.substringAfter(",", raw)
            try {
                val bytes = android.util.Base64.decode(cleanB64, android.util.Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp == null) {
                    dispatchOcrResult(cb, "", "Native Offline ML Kit (Invalid Image)")
                    return
                }
                val image = InputImage.fromBitmap(bmp, 0)
                val useDevanagari = (lang ?: "").contains("hin", ignoreCase = true) || (lang ?: "").contains("san", ignoreCase = true)
                val recognizer = if (useDevanagari) {
                    TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
                } else {
                    TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                }
                val engineName = if (useDevanagari) "Native Offline ML Kit (Devanagari)" else "Native Offline ML Kit (Latin)"
                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        dispatchOcrResult(cb, visionText.text ?: "", engineName)
                        recognizer.close()
                    }
                    .addOnFailureListener {
                        dispatchOcrResult(cb, "", "Native Offline ML Kit (Failed)")
                        recognizer.close()
                    }
            } catch (e: Exception) {
                dispatchOcrResult(cb, "", "Native Offline ML Kit (Error)")
            }
        }

        private fun dispatchOcrResult(cbId: String, text: String, engine: String) {
            val js = "window.__vidaraOcrCallback && window.__vidaraOcrCallback(" +
                JSONObject.quote(cbId) + "," + JSONObject.quote(text) + "," + JSONObject.quote(engine) + ");"
            runOnUiThread { webView.evaluateJavascript(js, null) }
        }

        @JavascriptInterface
        fun printPage(jobName: String?) {
            val safeJob = if (jobName.isNullOrBlank()) "VIDARA_AI_STUDY_Paper" else jobName
            runOnUiThread {
                try {
                    val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val printAdapter = webView.createPrintDocumentAdapter(safeJob)
                    val attrs = PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build()
                    printManager.print(safeJob, printAdapter, attrs)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Print failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        /** Text exports (CSV, JSON, SVG source). The content is UTF-8 text. */
        @JavascriptInterface
        fun saveFile(filename: String, mimeType: String, content: String) {
            writeDownload(filename, mimeType, content.toByteArray(Charsets.UTF_8))
        }

        /** Binary exports (.doc, .ppt, .svg) arrive base64-encoded; they are decoded before writing. */
        @JavascriptInterface
        fun saveBase64File(filename: String, mimeType: String, base64Content: String) {
            val bytes = try {
                android.util.Base64.decode(base64Content.substringAfter(",", base64Content), android.util.Base64.DEFAULT)
            } catch (e: IllegalArgumentException) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Save failed: invalid file data", Toast.LENGTH_LONG).show() }
                return
            }
            writeDownload(filename, mimeType, bytes)
        }

        private fun writeDownload(filename: String, mimeType: String, bytes: ByteArray) {
            runOnUiThread {
                try {
                    val cleanName = filename.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    // Android MediaStore rejects MIME parameters such as ";charset=utf-8".
                    val cleanMime = mimeType.substringBefore(";").trim().ifBlank { "application/octet-stream" }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val values = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, cleanName)
                            put(MediaStore.Downloads.MIME_TYPE, cleanMime)
                            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        }
                        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        if (uri == null) {
                            Toast.makeText(this@MainActivity, "Could not create file in Downloads.", Toast.LENGTH_LONG).show()
                            return@runOnUiThread
                        }
                        val written = try {
                            contentResolver.openOutputStream(uri)?.use { out -> out.write(bytes) } != null
                        } catch (e: Exception) {
                            false
                        }
                        if (!written) {
                            deleteEmptyCameraRow(uri)
                            Toast.makeText(this@MainActivity, "Save failed: could not write the file.", Toast.LENGTH_LONG).show()
                            return@runOnUiThread
                        }
                        Toast.makeText(this@MainActivity, "Saved to Downloads: $cleanName", Toast.LENGTH_LONG).show()
                        try {
                            val share = Intent(Intent.ACTION_SEND).apply {
                                type = cleanMime
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            startActivity(Intent.createChooser(share, "Open or Share $cleanName"))
                        } catch (_: Exception) {
                        }
                    } else if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED
                    ) {
                        writeLegacyDownload(cleanName, bytes)
                    } else {
                        pendingSave = PendingSave(cleanName, bytes)
                        legacyStoragePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
