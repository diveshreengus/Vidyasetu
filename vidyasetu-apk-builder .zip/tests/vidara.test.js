/* Browser tests for VIDARA AI STUDY.
   Setup once:   npm install && npx playwright install chromium
   Run:          npm test
   Exits with code 1 if any check fails. */
const path = require('path');
const fs = require('fs');
const http = require('http');
const { chromium } = require('playwright');

const ASSETS = path.resolve(__dirname, '../app/src/main/assets');
const FILE_URL = 'file://' + path.join(ASSETS, 'index.html');
let passed = 0, failed = 0;
const results = [];
function check(name, ok, detail = '') {
  if (ok) passed++; else failed++;
  results.push((ok ? 'PASS ' : 'FAIL ') + name + (detail && !ok ? '  -> ' + detail : ''));
}

function serveAssets(port) {
  const types = { '.html': 'text/html', '.js': 'application/javascript', '.json': 'application/json', '.png': 'image/png' };
  const server = http.createServer((req, res) => {
    const rel = decodeURIComponent(req.url.split('?')[0]).replace(/^\/+/, '') || 'index.html';
    const file = path.join(ASSETS, rel.endsWith('/') ? rel + 'index.html' : rel);
    if (!file.startsWith(ASSETS) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise(resolve => server.listen(port, '127.0.0.1', () => resolve(server)));
}

async function openApp(browser, { http: base } = {}) {
  const ctx = await browser.newContext({ viewport: { width: 412, height: 860 }, acceptDownloads: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.addInitScript(() => {
    window.__bridgeCalls = [];
    window.AndroidBridge = {
      saveFile: (f, m, c) => window.__bridgeCalls.push(['saveFile', f, m, c ? c.length : 0]),
      saveBase64File: (f, m, c) => window.__bridgeCalls.push(['saveBase64File', f, m, c ? c.length : 0]),
      printPage: j => window.__bridgeCalls.push(['printPage', j]),
      printHtml: (j, h) => window.__bridgeCalls.push(['printHtml', j, h ? h.length : 0]),
      runOfflineOcr: (img, lang, cb) => setTimeout(() => window.__vidaraOcrCallback && window.__vidaraOcrCallback(cb, '', 'Native Offline ML Kit (Latin)'), 30)
    };
  });
  await page.route(/^https?:\/\//, r => (base && r.request().url().startsWith(base)) ? r.continue() : r.abort());
  await page.goto(base ? base + '/index.html' : FILE_URL, { waitUntil: 'load' });
  await page.waitForTimeout(600);
  return { ctx, page, errors };
}

async function pickTeacher(page) {
  await page.click('#choose-role-teacher');
  await page.waitForTimeout(250);
}

async function autoPick(page, cls, subjLabel, chapters, counts) {
  return page.evaluate(([cls, subjLabel, chapters, counts]) => {
    document.getElementById('sel-class').value = cls;
    populateSubjectsForClass();
    document.getElementById('sel-subject').value = [...document.getElementById('sel-subject').options].find(o => o.textContent === subjLabel).value;
    state.selectedChapters = chapters; state.selectedTopics = []; state.scopeMode = 'full';
    for (const [id, v] of Object.entries(counts)) document.getElementById(id).value = String(v);
    let threw = null;
    try { autoPickRequestedQuestions(); } catch (e) { threw = e.message; }
    const qs = state.selectedIds.map(id => state.bank.find(q => q.id === id)).filter(Boolean);
    const stems = qs.map(q => String(q.stem || '').trim().toLowerCase());
    return { threw, n: qs.length, dupStems: stems.length - new Set(stems).size };
  }, [cls, subjLabel, chapters, counts]);
}

async function main() {
  const browser = await chromium.launch();
  const server = await serveAssets(0); const BASE = 'http://127.0.0.1:' + server.address().port;
  try {
    /* ---- Startup and navigation ---- */
    {
      const { ctx, page, errors } = await openApp(browser);
      check('app loads with no page errors (offline)', errors.length === 0, errors.join(' | '));
      check('splash/role screen shows', await page.isVisible('#choose-role-teacher'));
      await pickTeacher(page);
      const tabErrors = [];
      for (const t of ['t-tab-wizard', 't-tab-source', 't-tab-scan', 't-tab-export', 't-tab-omr', 't-tab-pyq', 't-tab-history', 't-tab-ncert', 't-tab-handwritten']) {
        await page.click('#' + t); await page.waitForTimeout(150);
      }
      check('all teacher tabs open without errors', errors.length === 0, errors.join(' | '));
      await ctx.close();
    }

    /* ---- Paper building: duplicates, Hindi crash, honest message ---- */
    {
      const { ctx, page, errors } = await openApp(browser);
      await pickTeacher(page);
      const sci = await autoPick(page, 'Class 10', 'Science (Combined)', [1,2,3,4,5,6,7,8,9,10,11,12,13], { 'cnt-mcq': 60, 'cnt-one': 10, 'cnt-sa': 20, 'cnt-la': 5, 'cnt-num': 5 });
      check('100-question Science paper fills exactly', sci.n === 100 && !sci.threw, JSON.stringify(sci));
      check('no question repeated inside one paper', sci.dupStems === 0, 'repeats: ' + sci.dupStems);
      const hin = await autoPick(page, 'Class 10', 'हिन्दी (Hindi)', [1], { 'cnt-mcq': 20, 'cnt-one': 0, 'cnt-sa': 0, 'cnt-la': 0, 'cnt-num': 0 });
      check('Hindi MCQ over-request does not throw', hin.threw === null, hin.threw || '');
      const toast = await page.evaluate(() => document.body.innerText.match(/Selected \d+ of \d+ unique/) ? 'honest' : 'none');
      check('shortage is reported honestly', toast === 'honest' || hin.n < 20);
      check('no page errors during paper building', errors.length === 0, errors.join(' | '));
      await ctx.close();
    }

    /* ---- Bridge routing for binary and text exports ---- */
    {
      const { ctx, page, errors } = await openApp(browser);
      await pickTeacher(page);
      const modId = await page.evaluate(() => VIDARA_PCB_LIBRARY[0].id);
      await page.evaluate(id => exportVidaraModuleDoc(id), modId); await page.waitForTimeout(300);
      const calls = () => page.evaluate(() => window.__bridgeCalls.map(c => c.slice(0, 3)));
      check('module Word export uses saveBase64File', (await calls()).some(c => c[0] === 'saveBase64File' && /\.doc$/.test(c[1])));
      await page.evaluate(() => { document.getElementById('generated-notes-body').innerHTML = '<p>Notes</p>'; document.getElementById('btn-download-notes-doc').click(); });
      check('notes .doc download uses the bridge', (await calls()).some(c => c[0] === 'saveFile' && /Notes/.test(c[1])));
      await page.click('#btn-open-settings'); await page.waitForTimeout(200);
      await page.click('#btn-download-backup'); await page.waitForTimeout(200);
      check('JSON backup uses the bridge', (await calls()).some(c => c[0] === 'saveFile' && /Backup/.test(c[1])));
      await page.keyboard.press('Escape'); await page.waitForTimeout(200);
      check('Escape closes Settings', await page.evaluate(() => document.getElementById('settings-modal').classList.contains('hidden')));
      check('no page errors during exports', errors.length === 0, errors.join(' | '));
      await ctx.close();
    }

    /* ---- Paper print, sets, header, check ---- */
    {
      const { ctx, page, errors } = await openApp(browser);
      await pickTeacher(page);
      await autoPick(page, 'Class 10', 'Science (Combined)', [1], { 'cnt-mcq': 6, 'cnt-one': 0, 'cnt-sa': 0, 'cnt-la': 0, 'cnt-num': 0 });
      await page.evaluate(() => renderExportPreview());
      await page.click('#t-tab-export'); await page.waitForTimeout(200);
      await page.click('#btn-print-pdf'); await page.waitForTimeout(200);
      check('paper print uses printHtml with a full document', await page.evaluate(() => window.__bridgeCalls.some(c => c[0] === 'printHtml' && c[2] > 5000)));
      const keys = await page.evaluate(() => {
        const orig = getSelectedQuestions();
        const out = {};
        for (const set of ['A', 'B']) {
          document.getElementById('pm-set').value = set;
          out[set] = applyPaperSet(orig).filter(q => q.type === 'MCQ').every(q => q.options[q.correctIndex] === q.answerKey.slice(3, -1) && 'ABCD'[q.correctIndex] === q.answerKey[0]);
        }
        document.getElementById('pm-set').value = '';
        return out;
      });
      check('Set A answer keys match their options', keys.A === true);
      check('Set B answer keys match their options', keys.B === true);
      await page.evaluate(() => { document.getElementById('pm-set').value = 'B'; document.getElementById('pm-date').value = '2026-12-05'; document.getElementById('pm-teacher').value = 'Test Teacher'; document.getElementById('pm-teacher').dispatchEvent(new Event('change')); });
      const header = await page.evaluate(() => document.getElementById('export-preview-content').innerText);
      check('header shows Set B, date and teacher', /Set B/.test(header) && /05-12-2026/.test(header) && /Teacher: Test Teacher/.test(header));
      await page.evaluate(() => document.getElementById('btn-paper-check').click());
      const chk = await page.evaluate(() => document.getElementById('paper-check-output').innerText);
      check('paper check runs and reports a result', /Paper check passed|problem/.test(chk), chk.slice(0, 120));
      check('no page errors during paper features', errors.length === 0, errors.join(' | '));
      await ctx.close();
    }

    /* ---- CSV import ---- */
    {
      const { ctx, page, errors } = await openApp(browser);
      await pickTeacher(page);
      const parsed = await page.evaluate(() => VIDARA_FEATURES.parseCsv('a,"b ""q"", x",c\r\n1,"multi\nline",3\r\n'));
      check('CSV parser handles quotes, commas and newlines', parsed[0][1] === 'b "q", x' && parsed[1][1] === 'multi\nline', JSON.stringify(parsed));
      const csvPath = path.join(__dirname, '.tmp_import.csv');
      fs.writeFileSync(csvPath, [
        'class,subject,chapter,topic,type,marks,difficulty,question,option_a,option_b,option_c,option_d,correct,answer',
        'Class 10,Social Science,1,Nationalism,MCQ,1,Easy,"Which country was unified in 1871?",France,Germany,Italy,Spain,B,',
        'Class 10,Social Science,1,Nationalism,MCQ,1,Easy,Which option is none of the above?,None of the above,Alpha,Beta,Gamma,A,',
        'Class 10,Social Science,1,Nationalism,Short Answer,3,Moderate,Why did nationalism spread after 1848?,,,,,,It spread liberty and national unity.',
        'Class 10,Nope,1,,MCQ,1,Easy,Bad subject,a,b,c,d,A,',
        'Class 10,Social Science,1,,MCQ,1,Easy,Missing correct,a,b,c,d,Z,'
      ].join('\r\n'));
      await page.setInputFiles('#csv-file-input', csvPath); await page.waitForTimeout(600);
      fs.unlinkSync(csvPath);
      const msg = await page.evaluate(() => document.getElementById('csv-import-result').innerText);
      check('good CSV rows are imported', /3 question\(s\) imported/.test(msg), msg.slice(0, 120));
      check('bad CSV rows are reported with row numbers', /Row 5: subject/.test(msg) && /Row 6: correct must be/.test(msg), msg.slice(0, 200));
      const kept = await page.evaluate(() => state.bank.some(q => q.userAuthored && q.options.includes('None of the above')));
      check('teacher-written options are not filtered out', kept);
      check('no page errors during import', errors.length === 0, errors.join(' | '));
      await ctx.close();
    }

    /* ---- Student weak topics and OMR class sheet ---- */
    {
      const { ctx, page, errors } = await openApp(browser);
      await pickTeacher(page);
      await page.evaluate(() => {
        localStorage.setItem('vidara_student_attempts', JSON.stringify([
          { id: 'a1', title: 'T', score: 5, maxScore: 10, acc: 50, correct: 5, wrong: 5, skipped: 0, totalQ: 10, timeSec: 100, date: 'x', topics: [{ name: 'Electricity', c: 1, tot: 4 }, { name: 'Light', c: 4, tot: 4 }] },
          { id: 'a2', title: 'T2', score: 3, maxScore: 10, acc: 30, correct: 3, wrong: 7, skipped: 0, totalQ: 10, timeSec: 100, date: 'y', topics: [{ name: 'Electricity', c: 0, tot: 2 }] }
        ]));
        renderStudentAnalytics();
      });
      const weak = await page.evaluate(() => document.getElementById('weak-topics-panel').innerText);
      check('weak topics ranked lowest first', weak.indexOf('Electricity') < weak.indexOf('Light') && /17%/.test(weak), weak.slice(0, 120));
      await page.click('#t-tab-omr'); await page.waitForTimeout(200);
      await page.click('#btn-build-neet-180'); await page.waitForTimeout(500);
      for (const name of ['Asha', 'Ravi']) {
        await page.click('#btn-omr-demo-fill'); await page.waitForTimeout(150);
        await page.fill('#omr-student-name', name);
        await page.click('#btn-omr-auto-grade'); await page.waitForTimeout(150);
        await page.click('#btn-omr-save-class'); await page.waitForTimeout(150);
      }
      check('two students saved to the class sheet', (await page.evaluate(() => document.getElementById('omr-class-count').innerText)).includes('2 student'));
      await page.click('#btn-omr-class-csv'); await page.waitForTimeout(200);
      check('class sheet CSV is saved through the bridge', await page.evaluate(() => window.__bridgeCalls.some(c => c[0] === 'saveFile' && /Class_Sheet/.test(c[1]))));
      check('no page errors during analytics and OMR', errors.length === 0, errors.join(' | '));
      await ctx.close();
    }

    /* ---- Offline web cache (over HTTP, network off) ---- */
    {
      const base = BASE;
      const { ctx, page, errors } = await openApp(browser, { http: base });
      await page.waitForTimeout(1500);
      await page.evaluate(() => navigator.serviceWorker.ready);
      await page.waitForTimeout(1500);
      await page.reload({ waitUntil: 'load' }); await page.waitForTimeout(400);
      await ctx.setOffline(true);
      await page.reload({ waitUntil: 'load' }); await page.waitForTimeout(400);
      check('app opens offline after first visit', await page.evaluate(() => !!document.getElementById('choose-role-teacher') || !!document.getElementById('csv-import-card')));
      check('no page errors offline', errors.length === 0, errors.join(' | '));
      await ctx.close();
    }
  } finally {
    await browser.close();
    server.close();
  }
  console.log(results.join('\n'));
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
}

main().catch(e => { console.error('TEST RUNNER ERROR:', e); process.exit(1); });
